# spring-mycontact
Simple CRUD app using:
- Spring Boot
- Spring MVC 
- Spring Data JPA 
- Thymeleaf
