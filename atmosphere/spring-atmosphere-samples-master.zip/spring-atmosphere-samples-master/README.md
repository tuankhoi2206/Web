Spring Atmosphere Samples
=========================

This repository illustrates integration scenarios between [Atmosphere][] and Spring MVC as well as [Spring Integration][]. The following 2 samples are provided:

* spring-mvc-atmosphere-sample
* spring-integration-atmosphere-sample

[Atmosphere]: https://github.com/Atmosphere/atmosphere
[Spring Integration]: http://www.springsource.org/spring-integration

